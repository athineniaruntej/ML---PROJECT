"""
Accident Hotspot Prediction Package
"""
